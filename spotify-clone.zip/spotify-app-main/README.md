# spotify-app
Spotify Clone is a web-based music streaming interface inspired by the official Spotify app. It replicates key features like navigation, playlists, recently played tracks, trending charts, and a responsive music player.
